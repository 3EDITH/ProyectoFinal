package logico;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Conexion {
    public static Connection getConexion() {
        String connectionUrl = "jdbc:sqlserver://192.168.100.118;encrypt=false;databaseName=Prueba_Altice_Grupo2;user=eguzman;password=Eg37229#2022";

        try {
            Connection con = DriverManager.getConnection(connectionUrl); 
            return con;

        }
        catch (SQLException ex) {
            System.out.println(ex.toString());
            return null;
        }
    }
}
