package logico;

import java.sql.ResultSet;
import java.sql.SQLException;

public class Prueba {

	public static void main(String[] args) {
		try {
			java.sql.Statement sqlStatement = Conexion.getConexion().createStatement();
			String consulta = "SELECT * FROM PERSONAL";
			ResultSet resultadoResultSet = sqlStatement.executeQuery(consulta);
			while(resultadoResultSet.next()) {
	
				System.out.println(resultadoResultSet.getString("Nombre")+" "+resultadoResultSet.getString("Apellido")+" "+resultadoResultSet.getString("Direccion"));
			}
			
		} catch (SQLException  ex) {
			System.out.println(ex.toString());
		}
	}

}
