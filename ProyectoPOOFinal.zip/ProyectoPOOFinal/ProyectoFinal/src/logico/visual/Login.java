package visual;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.border.TitledBorder;

import com.sun.javafx.event.EventQueue;

import logico.Administrador;
import logico.Altice;
import logico.Conexion;
import logico.Trabajador;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.JTextPane;
import javax.swing.UIManager;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.Toolkit;
import java.awt.SystemColor;
import javax.swing.SwingConstants;

public class Login extends JFrame {

	private final JPanel contentPanel = new JPanel();
	private JTextField txtUser;
	private JPasswordField password;
	private JButton btnIniciar;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
				
			}
		});
		
	}

	/**
	 * Create the dialog.
	 */
	public Login() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(Login.class.getResource("/imagenes/logo altice pf.PNG")));
		setResizable(false);

		setTitle("Altice - Iniciar sesi\u00F3n");
		setBounds(100, 100, 525, 333);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(SystemColor.window);
		contentPanel.setBorder(new TitledBorder(null, "", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		contentPanel.setLayout(null);
		setLocationRelativeTo(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(0, 0, 0));
		panel.setBounds(304, 0, 205, 315);
		contentPanel.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setBounds(-45, 80, 275, 142);
		lblNewLabel.setIcon(new ImageIcon(Login.class.getResource("/imagenes/image.png")));
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon(Login.class.getResource("/imagenes/icons8-male-user-100.png")));
		lblNewLabel_1.setBounds(95, 11, 107, 100);
		contentPanel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Iniciar Sesi\u00F3n");
		lblNewLabel_2.setFont(new Font("Arial", Font.BOLD, 20));
		lblNewLabel_2.setBounds(83, 121, 155, 16);
		contentPanel.add(lblNewLabel_2);
		
		txtUser = new JTextField();
		txtUser.setBounds(134, 162, 155, 18);
		contentPanel.add(txtUser);
		txtUser.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("Usuario o Email:");
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setFont(new Font("Arial", Font.PLAIN, 15));
		lblNewLabel_3.setBounds(10, 164, 114, 18);
		contentPanel.add(lblNewLabel_3);
		
		password = new JPasswordField();
		password.setBounds(134, 205, 155, 18);
		contentPanel.add(password);
		
		JLabel lblContrasea = new JLabel("Contrase\u00F1a:");
		lblContrasea.setHorizontalAlignment(SwingConstants.CENTER);
		lblContrasea.setFont(new Font("Arial", Font.PLAIN, 15));
		lblContrasea.setBounds(10, 207, 114, 18);
		contentPanel.add(lblContrasea);
		
		btnIniciar = new JButton("Ingresar");
		btnIniciar.setFont(new Font("Arial", Font.PLAIN, 15));
		btnIniciar.setIcon(new ImageIcon(Login.class.getResource("/imagenes/logo siguiente.png")));
		btnIniciar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent arg0) {
				btnIniciar.setBackground(Color.BLUE);
			}
			@Override
			public void mouseExited(MouseEvent arg0) {
				btnIniciar.setBackground(UIManager.getColor("control"));
			}
		});
		btnIniciar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				if(!txtUser.getText().isEmpty() && password.getPassword().length>0) {
					boolean encontrado = false;
					Administrador temp = null;
					try {
						java.sql.Statement sqlStatement = Conexion.getConexion().createStatement();
						String consulta = "SELECT * FROM Personal_de_la_empresa";
						ResultSet resultadoResultSet = sqlStatement.executeQuery(consulta);
						while(resultadoResultSet.next()) {
							System.out.println(String.valueOf(password.getPassword())+"   "+resultadoResultSet.getString("Usuario")+"    "+resultadoResultSet.getString("Contrasena") );
							if(resultadoResultSet.getString("Usuario").equals(txtUser.getText()) && resultadoResultSet.getString("Contrasena").equals(String.valueOf(password.getPassword()))) {
								encontrado = true;
								
							}
							//System.out.println(resultadoResultSet.getString("Nombre")+" "+resultadoResultSet.getString("Apellido")+" "+resultadoResultSet.getString("Direccion"));
						}
						
					} catch (SQLException  ex) {
						System.out.println(ex.toString());
					}
					if(encontrado == true){
						System.out.println("Usuario encontrado");
						Menu menu = new Menu(null);
						menu.setVisible(true);
						dispose();
					}else {
						JOptionPane.showMessageDialog(null, "No se ha encontrado el usuario", "Error", JOptionPane.ERROR_MESSAGE);
					}
					/*String pass = String.valueOf(password.getPassword());
					if(Altice.getInstance().login(txtUser.getText(), pass) != null) {
						Trabajador admin = Altice.getInstance().login(txtUser.getText(), pass);
						Menu menu = new Menu(admin);
						menu.setVisible(true);
						dispose();
					}
					if(encontrado == true){
						System.out.println("Usuario encontrado");
					}else {
						JOptionPane.showMessageDialog(null, "No se ha encontrado el usuario", "Error", JOptionPane.ERROR_MESSAGE);
					}
				*/}
				else {
					JOptionPane.showMessageDialog(null, "Debe completar la informacion.", "Error", JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		btnIniciar.setBounds(144, 245, 135, 33);
		contentPanel.add(btnIniciar);
	}
}
